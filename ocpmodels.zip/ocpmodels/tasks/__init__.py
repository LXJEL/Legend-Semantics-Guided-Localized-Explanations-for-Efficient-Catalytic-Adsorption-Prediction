﻿#
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.

__all__ = ["TrainTask", "PredictTask", "ValidateTask", "RelxationTask"]

from .task import PredictTask, RelxationTask, TrainTask, ValidateTask

