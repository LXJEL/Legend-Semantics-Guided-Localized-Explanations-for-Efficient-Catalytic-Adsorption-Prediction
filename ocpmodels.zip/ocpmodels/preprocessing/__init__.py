﻿"""

This source code is licensed under the MIT license found in the
LICENSE file in the root directory of this source tree.
"""

from .atoms_to_graphs import AtomsToGraphs

